/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function DiaCorrecto(Dia0,Mes0,Anio0){
    
    var aux=false;
    
    if (Dia0>=1&&Dia0<=CantidadDias(Mes0,Anio0)){
        aux=true;
    }
    
    return aux;
}


function MesCorrecto(Dia0,Mes0){
    
    var aux=false;
    
    if (Mes0>=1&&Mes0<=12)
    {
        aux=true;
    }
    
    return aux;
}

function AnioCorrecto(Dia0,Mes0,Anio0){
    
    var aux=false;
    
    if (Anio0>=1)
    {
        aux=true;
    }
    
    return aux;
    
}


function FechaCorrecta(Dia0,Mes0,Anio0){
    
   
      var aux=false;

        if(DiaCorrecto(Dia0,Mes0,Anio0)&&MesCorrecto(Dia0,Mes0,Anio0)&&AnioCorrecto(Dia0,Mes0,Anio0))
        {
                aux=true;
                
                if (!Bisiesto(Anio0)&&FebreroBisiesto(Dia0,Mes0,Anio0)) //llamo a la funcio para saber si el dia que ingreso es 29 y el mes febrero de un anio biciesto
                    
                {
                        aux=false;
                }
                
            }
            
    return aux;
    
    
    
}


function FechaCorrecta1(Dia1,Mes1,Anio1){
    
   
   var Dia0=Dia1,Mes0=Mes1,Anio0=Anio1;
      var aux=false;

        if(DiaCorrecto(Dia0,Mes0,Anio0)&&MesCorrecto(Dia0,Mes0,Anio0)&&AnioCorrecto(Dia0,Mes0,Anio0))
        {
                aux=true;
                
                if (!Bisiesto(Anio0)&&FebreroBisiesto(Dia0,Mes0,Anio0)) //llamo a la funcio para saber si el dia que ingreso es 29 y el mes febrero de un anio biciesto
                    
                {
                        aux=false;
                }
                
            }
            
    return aux;
    
    
    
}



function FebreroBisiesto (Dia0,Mes0,Anio0)//funcion para saber si es un febrero de un anio biciesto
{
        var aux=false;

        if (!!Bisiesto(Anio0)&&Mes0===2&&Dia0===29)
        {
            aux=true;
        }
        return aux;
    }




function Bisiesto(Anio) 
{
    
    var resto4 = 0;
    var resto100 = 0;
    var resto400 = 0;
    var EsB = false;
    if (Anio >= 0)
    {
        resto4 = Anio%4;
        resto100 = Anio%100;
        resto400 = Anio%400;
        if ((resto4 === 0) && ((resto100 !== 0) || (resto400 === 0)))
        {
            EsB=true;
        }
        else
        {
            EsB=false;
        }
    }
    else
    {
    var EsB=false;
    }
    return EsB;
}

function CantidadDias (Mes,Anio)
{
    

if (Bisiesto(Anio))
{
if ((Mes===4)||(Mes===6)||(Mes===9)||(Mes===11))
{

  var Cantidad=30;    
}
else
{
    var Cantidad=31;
        
    
}
if (Mes===2)
        {
            var Cantidad=29;
        }
    
}
else 
{
    if (Mes===4||Mes===6||Mes===9||Mes===11)
{
    var Cantidad=30;    
}
else
{
    var Cantidad=31;
        
    if (Mes===2)
        {
            var Cantidad=28;
        }
}
}    
return Cantidad;

} 

function AnioBisiesto (Anio)
{
  if (Bisiesto(Anio))
    {
        var Cantidad=366;
    }
    else
    {
        var Cantidad=365;
    }

    return Cantidad;
    
}

 function DiasFinAnio(Dia,Mes,Anio)

{

         var au=Mes,Acum=0,aux=0,AXUX=0;
        
            for(var i=1;i<au;i++)
        {
           if(au!==i)
                {
                   var Mes=i;   
         
                    var Acum=Acum+CantidadDias(Mes,Anio);
           }
        }  

           var aux=AnioBisiesto(Anio);
           var aux1=Acum+Dia;
           
           var AUXU=aux-aux1;
    

        
    document.getElementById("boxResutl").value=AUXU;

                
        return AUXU;

     }


function DiasPrincipioAnio(Dia,Mes,Anio)
{
            

         var au=Mes,Acum=0,aux=0;
        
                
            for(var i=1;i<=au;i++)
        {
           if(au!==i)
                {
                    Mes=i;   
         
                    Acum=Acum+CantidadDias(Mes,Anio);
           }
        }  

           aux=(Acum+Dia);
                 
             
        return aux;
}

 function CantEntreFechas (Dia0,Mes0,Anio0,Dia1,Mes1,Anio1)
{
   

     var DifAnio=0,DifDias=0,contB=0,TA=0,TD=0;
    var D0=Dia0,M0=Mes0,A0=Anio0,D1=Dia1,M1=Mes1,A1=Anio1;
    
    DifAnio=A1-A0;
    DifDias=DiasFinAnio(D0,M0,A0) + DiasPrincipioAnio(D1,M1,A1);
    
                for(var i=A0+1;i<=A1;i++)
                {
                    if(Bisiesto(i))
                    {
                     contB++;  
                    } 
                }

                TA=(((DifAnio)-1)*365 + contB);
                TD=DifDias+TA;
                        
                        
              document.getElementById("boxResutl").value=TD;

    return TD;
}



function Boton()
{

    var Dia0 = parseInt(document.getElementById("caja1").value);//dia

    var Mes0 = parseInt(document.getElementById("caja2").value);//mes
    
    var Anio0 = parseInt(document.getElementById("caja3").value);//anio

    var Dia1 = parseInt(document.getElementById("caja4").value);//dia
    
    var Mes1 = parseInt(document.getElementById("caja5").value);//mes
    
    var Anio1 = parseInt(document.getElementById("caja6").value);//anio

    
    alert(CantEntreFechas(Dia0,Mes0,Anio0,Dia1,Mes1,Anio1));
    
          alert("La primera fecha es "+FechaCorrecta(Dia0,Mes0,Anio0));
            
          alert("la Segunda fecha es "+FechaCorrecta1(Dia1,Mes1,Anio1));



    
}

function Prueba(){
    
      var Dia0 = parseInt(document.getElementById("caja1").value);//dia

    var Mes0 = parseInt(document.getElementById("caja2").value);//mes
    
        var Anio0 = parseInt(document.getElementById("caja3").value);//anio
        
        
        

        alert("La primera fecha es "+FechaCorrecta(Dia0,Mes0,Anio0));
        
  

}

window.onload = function() 
{

    document.getElementById("botoncalcular").onclick = Boton;
    
}