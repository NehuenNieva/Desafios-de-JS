
class Persona { //clase  
    constructor (nombre,apellido,sexo) //constructor 
    {
 
    this.nombre=nombre;
    this.apellido=apellido;
    this.sexo=sexo;  
    
    }   
}

  BaseDatos=[];

function Boton () //funcion que cuando se ejecute el boton se creara un objeto y se inserta dentro de un vector BASEDATOS 
{
   const nombre = document.getElementById('cajaNombre').value;
   const apellido = document.getElementById('cajaApellido').value;
   const sexo = document.getElementById('cajaSexo').value;


    objeto = new Persona (nombre,apellido,sexo);
      
    BaseDatos.push(objeto);

    var CheckDinamico2 = '<input type="checkbox" name ="checkeliminar"' +  'id ="' + BaseDatos.length + '"' + '>'; //tag html de checkbox
    
    
    document.getElementById("tabla").innerHTML += '<tbody name="fila" id="'+BaseDatos.length +'"> <td>'+BaseDatos.length+'</td><td>' +objeto.nombre+ '</td><td>' +objeto.apellido+ '</td><td>' +objeto.sexo+ '</td> <td>  </td> <td>'+ CheckDinamico2 + '</td>  </tbody>';
//toma de la tabla del html, y cada vez que se ejecuta el boton la funcion, innerHTML va concatenar los datos del objeto que ingresa en usuario...
// y los agrega al html

}



function Eliminar(){       //funcion que por medio del boton eliminar y el checkbox se iran ocultando 
    var Checkboxes=document.getElementsByName("checkeliminar");
    
    for (var i=0;i<Checkboxes.length;i++){
        
        
        if(Checkboxes[i].checked){
            
           document.getElementById(Checkboxes[i].id).style.display = "none";
            
               
        }      
                
    }
    
    
}

function mos(){
    
    
       var fila= document.getElementsByName('fila');
       const Checkboxes=document.getElementsByName("checkeliminar");


      //   BaseEliminados.push(fila.id);
console.log(BaseEliminados);
           
           
          // console.log(BaseDatos);
}





