

function Matriz(){
matriz = new Array(4);


for (var i=0;i<matriz.length;i++)
{
    matriz[i];
    
}

matriz[0]='Muralla China';

matriz[1]='Cataratas del Iguazu';

matriz[2]='Chichen Itza';

matriz[3]='Perito Moreno';


return matriz;

}

function Muralla_China(matriz){
    
matriz[0]='Muralla China';
alert("El lugar seleccionado es "+matriz[0]);
console.log(matriz[0]);
    
}

function Cataratas_del_Iguazu(matriz){
    matriz[1]='Cataratas del Iguazu';
    alert("El lugar seleccionado es "+matriz[1]);

    console.log(matriz[1]);
}

function Chichen_Itza(matriz){
    matriz[2]='Chichen Itza';
    
    alert("El lugar seleccionado es "+matriz[2]);

    console.log(matriz[2]);
}

function Perito_Moreno(matriz){
    matriz[3]='Perito Moreno';
    alert("El lugar seleccionado es "+matriz[3]);

    console.log(matriz[3]);
}

window.onload = function() 
{
    
  document.getElementById("cajita1").onclick= Muralla_China ;
  document.getElementById("cajita2").onclick= Cataratas_del_Iguazu ;
  document.getElementById("cajita3").onclick= Chichen_Itza ;
  document.getElementById("cajita4").onclick= Perito_Moreno ;

};



